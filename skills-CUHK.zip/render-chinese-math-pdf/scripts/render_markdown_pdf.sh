#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -ne 2 ]; then
  printf 'usage: %s input.md output.pdf\n' "$0" >&2
  exit 2
fi

input=$1
output=$2
texlive_root=${TEXLIVE_ROOT:-/lustre/project/Stat/s1155246312/texlive}
skill_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)

if [ ! -f "$input" ]; then
  printf 'input not found: %s\n' "$input" >&2
  exit 1
fi
if [ ! -x "$texlive_root/bin/x86_64-linux/xelatex" ]; then
  printf 'xelatex not found under TEXLIVE_ROOT: %s\n' "$texlive_root" >&2
  exit 1
fi
if ! command -v pandoc >/dev/null 2>&1; then
  printf 'pandoc not found in PATH\n' >&2
  exit 1
fi

out_abs=$(python3 -c 'import os,sys; print(os.path.abspath(sys.argv[1]))' "$output")
mkdir -p "$(dirname -- "$out_abs")"
build_dir=$(mktemp -d "${TMPDIR:-/tmp}/render-chinese-math-pdf.XXXXXX")
cleanup() { rm -rf "$build_dir"; }
trap cleanup EXIT

cp "$input" "$build_dir/input.md"
perl -CSD -0pi -e 's/\x{E200}cite\x{E202}([^\x{E201}]*)\x{E201}/"[cite: " . ($x=$1) =~ s!\x{E202}!; !gr . "]"/ge' "$build_dir/input.md"
sed "s#__TEXLIVE_ROOT__#$texlive_root#g" "$skill_dir/templates/chinese_math_pandoc_header.tex.in" > "$build_dir/header.tex"

(
  cd "$build_dir"
  export PATH="$texlive_root/bin/x86_64-linux:$PATH"
  export TEXMFVAR="$build_dir/texmf-var"
  export TEXMFCONFIG="$build_dir/texmf-config"
  export TEXMFCACHE="$build_dir/texmf-cache"
  export OSFONTDIR="$texlive_root/texmf-dist/fonts/opentype/public/fandol//:/usr/share/fonts//"
  pandoc input.md -o output.pdf --pdf-engine=xelatex \
    -V papersize:a4 -V geometry:margin=18mm -H header.tex
)

cp "$build_dir/output.pdf" "$out_abs"
printf 'wrote %s\n' "$out_abs"
