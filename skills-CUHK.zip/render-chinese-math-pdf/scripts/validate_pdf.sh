#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -ne 1 ]; then
  printf 'usage: %s output.pdf\n' "$0" >&2
  exit 2
fi

pdf=$1
if [ ! -s "$pdf" ]; then
  printf 'PDF missing or empty: %s\n' "$pdf" >&2
  exit 1
fi

status=0
printf 'PDF exists: %s\n' "$pdf"
ls -lh "$pdf"

if command -v pdfinfo >/dev/null 2>&1; then
  pdfinfo "$pdf"
else
  printf 'SKIP: pdfinfo not found\n'
fi

text_file=$(mktemp "${TMPDIR:-/tmp}/render-chinese-math-pdf-text.XXXXXX")
cleanup() { rm -f "$text_file" preview-*.png; }
trap cleanup EXIT

if command -v pdftotext >/dev/null 2>&1; then
  pdftotext "$pdf" "$text_file"
  printf 'Extracted text preview:\n'
  sed -n '1,40p' "$text_file"
  if grep -Eq 'turn[0-9]+(view|search|fetch)[0-9]+|\[cite:|�' "$text_file"; then
    printf 'ERROR: extracted text still contains broken citation handles or replacement characters\n' >&2
    status=1
  fi
  if LC_ALL=C grep -q "$(printf '\xee\x88')" "$text_file"; then
    printf 'ERROR: extracted text may contain private-use citation glyph bytes\n' >&2
    status=1
  fi
else
  printf 'SKIP: pdftotext not found\n'
fi

if command -v pdffonts >/dev/null 2>&1; then
  pdffonts "$pdf"
else
  printf 'SKIP: pdffonts not found\n'
fi

if command -v pdftoppm >/dev/null 2>&1; then
  pdftoppm -f 1 -l 1 -r 120 -png "$pdf" preview
  ls -lh preview-*.png
else
  printf 'SKIP: pdftoppm not found\n'
fi

exit "$status"
