---
name: render-chinese-math-pdf
description: Render and validate Chinese or mixed Chinese/English mathematical Markdown and LaTeX documents as PDF on this Stat/CUHK host. Use for CJK technical prose, Unicode math, display equations, tables, Pandoc/XeLaTeX with the local TeX Live tree, GPT deep-research citation artifact cleanup, and PDF text/font/preview validation.
status: active
provenance: user-authored
trusted: true
requires_network: false
writes_files: true
executes_code: true
secrets_needed:
last_reviewed: 2026-06-29
profile_tags:
  - documents-media
  - pdf
  - chinese
  - math
recommended_scope: global
---
# Render Chinese Math PDF

Use this host-local skill when converting Chinese or mixed Chinese/English mathematical Markdown or LaTeX into a readable PDF.

## Host Defaults

- TeX Live root: `/lustre/project/Stat/s1155246312/texlive`
- TeX binaries: `/lustre/project/Stat/s1155246312/texlive/bin/x86_64-linux`
- Confirmed local packages: `xeCJK.sty`, `ctex.sty`
- Confirmed CJK fonts: Fandol OpenType fonts under `texmf-dist/fonts/opentype/public/fandol`
- Pandoc: prefer `pandoc` from `PATH`
- Poppler validators such as `pdfinfo`, `pdftotext`, `pdffonts`, and `pdftoppm` may be absent from `PATH`; probe before promising those checks.

Prefer the bundled scripts:

```bash
local_global_skills/render-chinese-math-pdf/scripts/render_markdown_pdf.sh input.md output.pdf
local_global_skills/render-chinese-math-pdf/scripts/validate_pdf.sh output.pdf
```

When the skill is loaded from `$HOME/.agents/skills/render-chinese-math-pdf`, use the same relative `scripts/...` paths from that skill directory.

## Workflow

1. Inspect the source for Chinese text, Unicode math, display math, tables, images, custom LaTeX macros, and GPT deep-research citation artifacts.
2. Copy the source into a temporary build directory unless the user explicitly wants outputs beside the source.
3. Normalize private-use citation markers and broken `turn...` citation handles before final rendering.
4. Render Markdown with the bundled `render_markdown_pdf.sh` script when possible. For existing LaTeX sources, prepend the local TeX Live bin directory and run `xelatex` with writable cache variables.
5. Validate the PDF with `validate_pdf.sh`; if Poppler tools are unavailable, report which checks were skipped.

## Markdown Cleanup Rules

- Keep short values, labels, tensor shapes, and one-term expressions inline: `$81$`, `$\texttt{myops\_scar}$`, `$K_m=2$`, `$[B,1,H,W,D]$`.
- Reserve `$$...$$` for equations that need their own line: multi-line derivations, aligned definitions, loss functions, or formulas too long to read inline.
- Prefer standard LaTeX commands. Replace one-off operators like `\logit(x)` with `\operatorname{logit}(x)` unless a macro is deliberately defined.
- Treat `citeturn11view0`, `[cite: turn11view0]`, and bare `turn11view0` tokens as broken export artifacts, not references.

## Citation Repair

If a matching raw PDF with real links is available, extract visible text and link structure with available tools such as `pdftotext` and `pdftohtml`, then map citation positions by document order. Replace broken markers with readable Markdown links and strip obvious tracking parameters such as `utm_source=chatgpt.com`.

If no raw PDF or source reference list is available, do not invent references from `turn...` handles. Remove broken markers for readability and report that true references could not be reconstructed.

## Manual Render Pattern

Use this pattern if the bundled script is not suitable:

```bash
export TEXLIVE_ROOT=/lustre/project/Stat/s1155246312/texlive
export PATH="$TEXLIVE_ROOT/bin/x86_64-linux:$PATH"
export TEXMFVAR="$PWD/texmf-var"
export TEXMFCONFIG="$PWD/texmf-config"
export TEXMFCACHE="$PWD/texmf-cache"
export OSFONTDIR="$TEXLIVE_ROOT/texmf-dist/fonts/opentype/public/fandol//:/usr/share/fonts//"
pandoc input.md -o output.pdf --pdf-engine=xelatex \
  -V papersize:a4 -V geometry:margin=18mm -H header.tex
```

## Validation

Before reporting success, check:

- PDF exists and is non-empty.
- Page count and page size, when `pdfinfo` is available.
- Extracted text contains the title, early content, and a late-section anchor, when `pdftotext` is available.
- CJK/math fonts are embedded, when `pdffonts` is available.
- First-page preview is nonblank and not severely clipped, when `pdftoppm` is available.
- Source and extracted text contain no private-use citation glyphs, `turn...` handles, `[cite:` fragments, or replacement characters.

If a validator is missing, say exactly which check was skipped instead of calling the PDF fully validated.
