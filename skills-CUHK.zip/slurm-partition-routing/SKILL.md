---
name: slurm-partition-routing
description: Global Slurm partition routing and sbatch header guidance for HPC jobs. Use before submitting or generating Slurm scripts to choose CPU vs GPU partitions, check live sinfo/squeue status, keep artifacts under jobs/, avoid CPU-only jobs on GPU nodes, and produce valid headers.
install_name: slurm-partition-routing
status: active
provenance: user-authored
trusted: true
requires_network: false
writes_files: true
executes_code: false
secrets_needed:
last_reviewed: 2026-06-20
profile_tags:
  - hpc
  - slurm
  - global
recommended_scope: global
---
# Slurm Partition Routing

Use this skill before submitting, generating, or editing Slurm jobs. The goal is
to avoid invalid jobs, avoid wasting GPU nodes on CPU-only work, and choose a
fallback only when live queue state justifies it.

## Non-Negotiable Rules

- Check live state before every submission. Do not treat old `sinfo`/`squeue`
  output as durable.
- Do not submit CPU-only work to GPU partitions.
- Do not switch away from the best GPU partition just because it is non-idle.
  Fallback only when the preferred queue is clearly worse than alternatives.
- If fallback queues are also poor or full, keep waiting on the preferred GPU
  partition instead of blindly switching.
- Keep generated Slurm artifacts in a repo-local `jobs/` directory by default:
  generated batch scripts under `jobs/<ShortJobName>.sbatch`, stdout as
  `jobs/<ShortJobName>_%j.out`, and stderr as `jobs/<ShortJobName>_%j.err`.
  For job arrays, include array identifiers such as `%A_%a` to avoid output
  collisions. Use another layout only when the user asks or the repository
  already has an explicit convention.
- Do not put generated Slurm scripts under `code/` unless the repository
  already has that explicit convention. Do not add script-level `tee` runtime
  logs unless the user asks for separate runtime logs or the repository already
  has that convention.
- Use `.agents/skills` installs and project `AGENTS.md` routing as usual; do
  not write `.codex/skills` for Slurm routing.

## Required Pre-Submit Checks

Run these immediately before choosing a partition:

```bash
sacctmgr -n -P show assoc user=$USER format=User,Account,Partition,QOS
sinfo -o '%P|%a|%D|%t|%c|%m|%G|%N'
sinfo -N -o '%N|%P|%t|%c|%m|%G|%f'
squeue -u "$USER" -o '%.10i %.15P %.30j %.10T %.12M %.12l %.20R'
```

When unsure whether a header is valid, use `sbatch --test-only` first. This
does not submit a job:

```bash
sbatch --test-only -p <partition> <other-sbatch-options> --wrap='hostname'
```

## Workflow

1. Classify the job:
   - `cpu-only`: no CUDA, no GPU memory, no GPU package requirement.
   - `gpu-training`: training, inference, image segmentation, deep learning, or
     any CUDA/GPU memory dependency.
   - `gpu-light`: short smoke tests or low-memory GPU validation.
2. Identify the cluster pattern:
   - CARE-style server with `htzhulab`, `a100-gpu`, `volta-gpu`.
   - CUHK Stat/CHPC server with `stat`, `statdgx`, `chpc`, `public`.
   - Unknown cluster: read live `scontrol show partition`, `sinfo`, and
     `sacctmgr` before adapting.
3. Pick the partition using the live-state rules below.
4. Generate a minimal valid header. Do not invent unsupported options.
5. Before submitting, verify that generated batch scripts, stdout, and stderr
   are under `jobs/`, output/error names match the task/job name by default,
   and logs are not lost.
6. Test the header with `sbatch --test-only` when available.

## CARE-Style GPU Priority

For GPU jobs on the CARE-style server:

1. Prefer `htzhulab`.
2. If `htzhulab` queue is clearly too long, try `a100-gpu`.
3. If `a100-gpu` is also poor, try `volta-gpu`.
4. If fallbacks are also full or worse, keep waiting on `htzhulab`.

Fallback headers for `a100-gpu` and `volta-gpu` must include:

```bash
#SBATCH --qos=gpu_access
```

CPU-only jobs on that server should use `general` or another CPU partition, not
`htzhulab`, `a100-gpu`, or `volta-gpu`.

## CUHK Stat/CHPC Priority

Use this only after refreshing live Slurm state on the CUHK Stat cluster:

- GPU priority:
  1. `stat` with `--gres=gpu:H200:1`
  2. `statdgx` with `--gres=gpu:A100:1`
  3. `stat` with `--gres=gpu:V100:1`
- CPU priority:
  1. `stat`
  2. `chpc` for larger CPU or memory jobs that fit partition limits
  3. `public` as small fallback

Do not use `bzhou` or `diir` unless the user's account association explicitly
allows those partitions. Do not assume `chpc` GPU nodes are usable just because
they appear in `sinfo`; verify with `sbatch --test-only`.

## Header Templates

Use simple `#SBATCH` headers aligned with CARE/CardiacNexus-style generated job
scripts: one option per line, no shell logic inside directives, and runtime
logic after directives.

### CARE GPU Preferred

```bash
#!/bin/bash
#SBATCH --job-name=<ShortJobName>
#SBATCH --partition=htzhulab
#SBATCH --gres=gpu:1
#SBATCH --cpus-per-task=<cpus>
#SBATCH --mem=<memory>
#SBATCH --time=<days-hours:minutes:seconds>
#SBATCH --output=jobs/<ShortJobName>_%j.out
#SBATCH --error=jobs/<ShortJobName>_%j.err

set -euo pipefail
mkdir -p jobs
```

### CARE GPU Fallback

```bash
#!/bin/bash
#SBATCH --job-name=<ShortJobName>
#SBATCH --partition=a100-gpu
#SBATCH --qos=gpu_access
#SBATCH --gres=gpu:1
#SBATCH --cpus-per-task=<cpus>
#SBATCH --mem=<memory>
#SBATCH --time=<days-hours:minutes:seconds>
#SBATCH --output=jobs/<ShortJobName>_%j.out
#SBATCH --error=jobs/<ShortJobName>_%j.err

set -euo pipefail
mkdir -p jobs
```

For `volta-gpu`, keep the same fallback template and change only
`--partition=volta-gpu`.

### CPU-Only

```bash
#!/bin/bash
#SBATCH --job-name=<ShortJobName>
#SBATCH --partition=general
#SBATCH --cpus-per-task=<cpus>
#SBATCH --mem=<memory>
#SBATCH --time=<days-hours:minutes:seconds>
#SBATCH --output=jobs/<ShortJobName>_%j.out
#SBATCH --error=jobs/<ShortJobName>_%j.err

set -euo pipefail
mkdir -p jobs
```

### CUHK Stat H200

```bash
#!/bin/bash
#SBATCH --job-name=<ShortJobName>
#SBATCH --partition=stat
#SBATCH --account=stat
#SBATCH --gres=gpu:H200:1
#SBATCH --cpus-per-task=<cpus>
#SBATCH --mem=<memory>
#SBATCH --time=<days-hours:minutes:seconds>
#SBATCH --output=jobs/<ShortJobName>_%j.out
#SBATCH --error=jobs/<ShortJobName>_%j.err

set -euo pipefail
mkdir -p jobs
```

## References

- Read `references/slurm-routing-notes.md` when selecting a partition or
  explaining fallback decisions.
