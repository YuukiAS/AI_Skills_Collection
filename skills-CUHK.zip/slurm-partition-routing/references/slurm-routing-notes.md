# Slurm Routing Notes

These notes are procedural, not permanent cluster state. Always refresh live
Slurm status before submitting.

## Live-State Checks

Use these commands before choosing a partition:

```bash
sacctmgr -n -P show assoc user=$USER format=User,Account,Partition,QOS
sinfo -o '%P|%a|%D|%t|%c|%m|%G|%N'
sinfo -N -o '%N|%P|%t|%c|%m|%G|%f'
squeue -u "$USER" -o '%.10i %.15P %.30j %.10T %.12M %.12l %.20R'
```

Use `scontrol show partition` when available to inspect `AllowAccounts`,
`AllowQos`, `MaxTime`, nodes, and TRES. If controller access is blocked by the
runtime sandbox, rerun the read-only query with appropriate approval.

Validate candidates without submitting:

```bash
sbatch --test-only -p <partition> -A <account> --gres=<gpu-spec> --wrap='hostname'
```

## CARE-Style Server Rules

The durable routing policy is:

- GPU tasks default to `htzhulab`.
- If `htzhulab` is clearly too slow, fallback order is `a100-gpu`, then
  `volta-gpu`.
- If fallback queues are also poor or full, keep waiting on `htzhulab`.
- CPU-only tasks should use `general` or a suitable CPU partition.
- `a100-gpu` and `volta-gpu` fallback headers must include
  `#SBATCH --qos=gpu_access`.

Do not switch solely because a fallback GPU exists. Switch only when live
queue/availability makes it meaningfully better.

## CUHK Stat/CHPC Snapshot From 2026-06-20

This is an observed snapshot, not a permanent guarantee.

Association:

```text
user=s1155246312 account=stat qos=normal,stat
```

Partition access verified with `sbatch --test-only`:

- CPU jobs: `stat`, `public`, and `chpc` accepted CPU-only test jobs.
- GPU jobs:
  - `stat --gres=gpu:H200:1` accepted on `chpc-gpu040`.
  - `stat --gres=gpu:V100:1` accepted on `chpc-gpu010`.
  - `statdgx --gres=gpu:A100:1` accepted on `chpc-gpu019`.
  - `chpc` GPU requests for H200/A100/L40S/4090D/6000ADA/H800 did not match
    the user's account/QOS at that time.
  - `bzhou` and `diir` rejected the user's `stat` account.

Recommended CUHK priority from that snapshot:

1. GPU: `stat` H200.
2. GPU fallback: `statdgx` A100.
3. GPU fallback: `stat` V100.
4. CPU: `stat`, then `chpc`, then `public`.

## Valid Header Patterns

Use one directive per line. Do not put conditional shell logic in `#SBATCH`
directives. Keep runtime setup after the directives. Put generated batch
scripts and Slurm stdout/stderr under repo-local `jobs/` by default:
`jobs/<ShortJobName>.sbatch`, `jobs/<ShortJobName>_%j.out`, and
`jobs/<ShortJobName>_%j.err`. For job arrays, include array identifiers such as
`%A_%a` to avoid output collisions. Use `logs/` or script-level `tee` logs only
when the user asks or the repository already has that convention.

```bash
#!/bin/bash
#SBATCH --job-name=<ShortJobName>
#SBATCH --partition=stat
#SBATCH --account=stat
#SBATCH --gres=gpu:H200:1
#SBATCH --cpus-per-task=8
#SBATCH --mem=64G
#SBATCH --time=1-00:00:00
#SBATCH --output=jobs/<ShortJobName>_%j.out
#SBATCH --error=jobs/<ShortJobName>_%j.err

set -euo pipefail
mkdir -p jobs
```

For CPU-only jobs, omit `--gres` entirely and choose a CPU partition.
